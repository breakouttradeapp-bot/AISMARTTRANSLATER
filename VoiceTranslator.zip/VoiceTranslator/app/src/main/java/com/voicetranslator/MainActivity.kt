package com.voicetranslator

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.material.snackbar.Snackbar
import com.voicetranslator.databinding.ActivityMainBinding
import com.voicetranslator.utils.AdManager
import com.voicetranslator.utils.LanguageUtils
import com.voicetranslator.utils.NetworkUtils
import com.voicetranslator.utils.PrefsManager
import com.voicetranslator.viewmodel.MainViewModel
import java.util.*

/**
 * MainActivity — the primary translator screen.
 * Features: voice input, text translation, TTS output, language selection, AdMob.
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var prefs: PrefsManager
    private lateinit var adManager: AdManager

    // Text-To-Speech engine
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // Speech recognizer
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    companion object {
        // Test Banner Ad Unit ID — replace with real ID for production
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    }

    // Permission launcher for RECORD_AUDIO
    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceInput()
        else showError("Microphone permission is required for voice input.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)
        adManager = AdManager(this)

        setupToolbar()
        setupLanguageSpinners()
        setupClickListeners()
        setupBannerAd()
        setupViewModel()

        // Initialize TTS engine
        tts = TextToSpeech(this, this)

        // Preload interstitial ad
        adManager.loadInterstitialAd()
    }

    // ─── Toolbar ─────────────────────────────────────────────────────────────

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // ─── Language Spinners ────────────────────────────────────────────────────

    private fun setupLanguageSpinners() {
        val langNames = LanguageUtils.displayNames
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, langNames).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // Source language spinner
        binding.spinnerSource.adapter = adapter
        binding.spinnerSource.setSelection(LanguageUtils.getIndexByCode(prefs.sourceLang))
        binding.spinnerSource.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.sourceLang = LanguageUtils.languages[pos].second
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Target language spinner
        binding.spinnerTarget.adapter = adapter
        binding.spinnerTarget.setSelection(LanguageUtils.getIndexByCode(prefs.targetLang))
        binding.spinnerTarget.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.targetLang = LanguageUtils.languages[pos].second
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    // ─── Click Listeners ──────────────────────────────────────────────────────

    private fun setupClickListeners() {

        // Translate button
        binding.btnTranslate.setOnClickListener {
            val text = binding.etInputText.text.toString().trim()
            if (!NetworkUtils.isConnected(this)) {
                showError("No internet connection. Please check your network settings.")
                return@setOnClickListener
            }
            if (text.isBlank()) {
                binding.etInputText.error = "Please enter or speak text to translate"
                return@setOnClickListener
            }
            viewModel.translate(text, prefs.sourceLang, prefs.targetLang)
        }

        // Microphone (voice input) button
        binding.btnMic.setOnClickListener {
            checkMicrophonePermission()
        }

        // Swap languages button
        binding.btnSwap.setOnClickListener {
            val srcIndex = binding.spinnerSource.selectedItemPosition
            val tgtIndex = binding.spinnerTarget.selectedItemPosition
            binding.spinnerSource.setSelection(tgtIndex)
            binding.spinnerTarget.setSelection(srcIndex)

            // Also swap text fields
            val inputText = binding.etInputText.text.toString()
            val outputText = binding.tvTranslatedText.text.toString()
            if (outputText.isNotBlank() && outputText != getString(R.string.translation_hint)) {
                binding.etInputText.setText(outputText)
                binding.tvTranslatedText.text = inputText
            }

            // Rotation animation on swap button
            val rotateAnim = AnimationUtils.loadAnimation(this, R.anim.rotate_360)
            binding.btnSwap.startAnimation(rotateAnim)
        }

        // TTS button (speak translated text)
        binding.btnSpeak.setOnClickListener {
            val text = binding.tvTranslatedText.text.toString()
            if (text.isNotBlank() && text != getString(R.string.translation_hint)) {
                speakText(text, prefs.targetLang)
            } else {
                Toast.makeText(this, "Nothing to speak yet", Toast.LENGTH_SHORT).show()
            }
        }

        // Copy translated text to clipboard
        binding.btnCopy.setOnClickListener {
            val text = binding.tvTranslatedText.text.toString()
            if (text.isNotBlank() && text != getString(R.string.translation_hint)) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Translation", text))
                Snackbar.make(binding.root, "Copied to clipboard", Snackbar.LENGTH_SHORT).show()
            }
        }

        // Clear input
        binding.btnClear.setOnClickListener {
            binding.etInputText.text?.clear()
            binding.tvTranslatedText.text = getString(R.string.translation_hint)
            viewModel.resetState()
        }
    }

    // ─── ViewModel Observers ──────────────────────────────────────────────────

    private fun setupViewModel() {
        viewModel.translationState.observe(this) { state ->
            when (state) {
                is MainViewModel.TranslationState.Loading -> {
                    showLoading(true)
                }
                is MainViewModel.TranslationState.Success -> {
                    showLoading(false)
                    displayTranslation(state.translatedText)

                    // Auto-speak if TTS enabled
                    if (prefs.ttsEnabled) {
                        speakText(state.translatedText, prefs.targetLang)
                    }

                    // Show interstitial ad every 3 translations
                    adManager.showInterstitialIfReady(this, prefs)
                }
                is MainViewModel.TranslationState.Error -> {
                    showLoading(false)
                    showError(state.message)
                }
                is MainViewModel.TranslationState.Idle -> {
                    showLoading(false)
                }
            }
        }
    }

    // ─── UI Helpers ───────────────────────────────────────────────────────────

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnTranslate.isEnabled = !show
        binding.btnTranslate.text = if (show) "" else getString(R.string.btn_translate)
    }

    private fun displayTranslation(text: String) {
        binding.tvTranslatedText.text = text

        // Slide up animation on result card
        val anim = AnimationUtils.loadAnimation(this, R.anim.slide_up_fade_in)
        binding.cardTranslation.startAnimation(anim)
        binding.cardTranslation.visibility = View.VISIBLE
    }

    private fun showError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .setIcon(R.drawable.ic_error)
            .show()
    }

    // ─── Voice Input ──────────────────────────────────────────────────────────

    private fun checkMicrophonePermission() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED -> startVoiceInput()

            shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO) -> {
                AlertDialog.Builder(this)
                    .setTitle("Microphone Permission")
                    .setMessage("Microphone access is needed to convert your speech to text.")
                    .setPositiveButton("Grant") { _, _ ->
                        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            else -> audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    /**
     * Starts the Android SpeechRecognizer for voice input.
     */
    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showError("Speech recognition is not available on this device.")
            return
        }

        if (isListening) {
            stopVoiceInput()
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                binding.btnMic.setIconTintResource(R.color.error)
                binding.tvVoiceHint.visibility = View.VISIBLE
                binding.tvVoiceHint.text = "Listening..."
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    binding.etInputText.setText(matches[0])
                    // Auto-translate the spoken text
                    viewModel.translate(matches[0], prefs.sourceLang, prefs.targetLang)
                }
                stopVoiceInput()
            }

            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected. Try again."
                    SpeechRecognizer.ERROR_NETWORK -> "Network error during recognition."
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                    else -> "Voice recognition failed. Try again."
                }
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                stopVoiceInput()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.forLanguageTag(prefs.sourceLang))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer?.startListening(intent)
    }

    private fun stopVoiceInput() {
        isListening = false
        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
        binding.btnMic.setIconTintResource(R.color.md_theme_primary)
        binding.tvVoiceHint.visibility = View.GONE
    }

    // ─── Text To Speech ───────────────────────────────────────────────────────

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
        }
    }

    /**
     * Speaks the given text using the device TTS engine.
     *
     * @param text Text to speak.
     * @param langCode BCP-47 language code.
     */
    private fun speakText(text: String, langCode: String) {
        if (!ttsReady) return
        val locale = Locale.forLanguageTag(langCode)
        val result = tts?.setLanguage(locale)

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fall back to default locale
            tts?.setLanguage(Locale.getDefault())
        }

        tts?.setSpeechRate(prefs.ttsSpeed)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utteranceId")
    }

    // ─── AdMob Banner ─────────────────────────────────────────────────────────

    private fun setupBannerAd() {
        val adView = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = BANNER_AD_UNIT_ID
        }
        binding.adContainer.addView(adView)
        adView.loadAd(AdRequest.Builder().build())
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
