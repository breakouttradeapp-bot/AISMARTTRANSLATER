package com.voicetranslator

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.voicetranslator.databinding.ActivitySettingsBinding
import com.voicetranslator.utils.PrefsManager

/**
 * SettingsActivity — app preferences screen.
 * Includes theme toggle, TTS speed, and history management.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)

        setupToolbar()
        loadCurrentSettings()
        setupClickListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Settings"
        }
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    /**
     * Loads saved preferences into the UI controls.
     */
    private fun loadCurrentSettings() {
        // Theme selection chip group
        when (prefs.themeMode) {
            0 -> binding.chipSystem.isChecked = true
            1 -> binding.chipLight.isChecked = true
            2 -> binding.chipDark.isChecked = true
        }

        // TTS toggle
        binding.switchTts.isChecked = prefs.ttsEnabled

        // TTS speed seekbar (0.5 to 2.0, stored as 0-100 mapped range)
        val speedProgress = ((prefs.ttsSpeed - 0.5f) / 1.5f * 100).toInt()
        binding.seekbarTtsSpeed.progress = speedProgress
        updateSpeedLabel(prefs.ttsSpeed)
    }

    private fun setupClickListeners() {

        // Theme chip group
        binding.chipGroupTheme.setOnCheckedStateChangeListener { _, checkedIds ->
            val mode = when {
                checkedIds.contains(R.id.chipLight) -> {
                    prefs.themeMode = 1
                    AppCompatDelegate.MODE_NIGHT_NO
                }
                checkedIds.contains(R.id.chipDark) -> {
                    prefs.themeMode = 2
                    AppCompatDelegate.MODE_NIGHT_YES
                }
                else -> {
                    prefs.themeMode = 0
                    AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            }
            AppCompatDelegate.setDefaultNightMode(mode)
        }

        // TTS toggle switch
        binding.switchTts.setOnCheckedChangeListener { _, checked ->
            prefs.ttsEnabled = checked
        }

        // TTS speed seekbar
        binding.seekbarTtsSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Map 0-100 to 0.5-2.0 range
                val speed = 0.5f + (progress / 100f * 1.5f)
                prefs.ttsSpeed = speed
                updateSpeedLabel(speed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // API Key info
        binding.tvApiKeyInfo.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("API Key Configuration")
                .setMessage(
                    "To use the translation service:\n\n" +
                    "1. Register at rapidapi.com\n" +
                    "2. Subscribe to 'Deep Translate'\n" +
                    "3. Copy your API key\n" +
                    "4. Open app/build.gradle\n" +
                    "5. Replace YOUR_RAPIDAPI_KEY_HERE with your key\n" +
                    "6. Rebuild the app"
                )
                .setPositiveButton("OK", null)
                .show()
        }

        // Clear history
        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("This will permanently delete all saved translations.")
                .setPositiveButton("Clear") { _, _ ->
                    com.voicetranslator.data.DatabaseHelper(this).clearAllHistory()
                    Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun updateSpeedLabel(speed: Float) {
        val label = when {
            speed < 0.7f -> "Slow (${String.format("%.1f", speed)}x)"
            speed < 1.3f -> "Normal (${String.format("%.1f", speed)}x)"
            else -> "Fast (${String.format("%.1f", speed)}x)"
        }
        binding.tvTtsSpeedLabel.text = label
    }
}
