/**
 * Firebase Cloud Functions — AI Smart Translator Backend
 *
 * This is the SECURE backend that holds the RapidAPI key.
 * The Android app NEVER has direct access to the API key.
 *
 * Setup:
 *   1. cd firebase-functions
 *   2. npm install
 *   3. firebase functions:config:set rapidapi.key="YOUR_RAPIDAPI_KEY_HERE"
 *   4. firebase deploy --only functions
 *
 * The API key is stored in Firebase environment config,
 * never in source code or in the APK.
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const axios = require('axios');

admin.initializeApp();

// ===== RATE LIMITING =====
// Store per-IP request counts in memory (for production, use Firestore or Redis)
const rateLimitMap = new Map();
const RATE_LIMIT = 30;       // max 30 requests
const WINDOW_MS = 60 * 1000; // per minute

function checkRateLimit(ip) {
  const now = Date.now();
  const entry = rateLimitMap.get(ip) || { count: 0, windowStart: now };

  if (now - entry.windowStart > WINDOW_MS) {
    // Reset window
    entry.count = 1;
    entry.windowStart = now;
  } else {
    entry.count++;
  }

  rateLimitMap.set(ip, entry);
  return entry.count <= RATE_LIMIT;
}

// ===== CALLABLE FUNCTION (recommended) =====
/**
 * Translate text using RapidAPI Deep Translate.
 *
 * Called from Android via:
 *   FirebaseFunctions.getInstance().getHttpsCallable("translate").call(data)
 *
 * Input:  { q: string, source: string, target: string }
 * Output: { translatedText: string }
 */
exports.translate = functions
  .region('us-central1') // Change to your preferred region
  .https.onCall(async (data, context) => {

    // --- Input validation ---
    const { q, source, target } = data;

    if (!q || typeof q !== 'string' || q.trim().length === 0) {
      throw new functions.https.HttpsError('invalid-argument', 'Text to translate is required.');
    }

    if (!source || !target) {
      throw new functions.https.HttpsError('invalid-argument', 'Source and target languages are required.');
    }

    if (q.length > 5000) {
      throw new functions.https.HttpsError('invalid-argument', 'Text too long. Max 5000 characters.');
    }

    const validLanguages = ['en', 'hi', 'mr', 'es', 'fr', 'de'];
    if (!validLanguages.includes(source) || !validLanguages.includes(target)) {
      throw new functions.https.HttpsError('invalid-argument', 'Unsupported language code.');
    }

    // --- Rate limiting ---
    // context.rawRequest is not available in callable, use context.auth uid or app check
    // For simplicity, rate-limit per authenticated session (use Firebase App Check in prod)
    const uid = context.auth ? context.auth.uid : 'anonymous';
    if (!checkRateLimit(uid)) {
      throw new functions.https.HttpsError('resource-exhausted', 'Rate limit exceeded. Please wait.');
    }

    // --- Get API key from Firebase environment config ---
    // Set with: firebase functions:config:set rapidapi.key="YOUR_KEY"
    const apiKey = functions.config().rapidapi?.key;

    if (!apiKey) {
      functions.logger.error('RapidAPI key not configured!');
      throw new functions.https.HttpsError('internal', 'Server configuration error.');
    }

    // --- Call RapidAPI Deep Translate ---
    try {
      const response = await axios.post(
        'https://deep-translate1.p.rapidapi.com/language/translate/v2',
        { q: q.trim(), source, target },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-rapidapi-host': 'deep-translate1.p.rapidapi.com',
            'x-rapidapi-key': apiKey,  // <-- API key ONLY here, never in APK
          },
          timeout: 10000, // 10 second timeout
        }
      );

      const translatedText = response.data?.data?.translations?.translatedText;

      if (!translatedText) {
        throw new functions.https.HttpsError('internal', 'Translation service returned empty result.');
      }

      functions.logger.info('Translation successful', { source, target, chars: q.length });

      return { translatedText };

    } catch (error) {
      if (error instanceof functions.https.HttpsError) throw error;

      functions.logger.error('RapidAPI call failed', error.message);

      if (error.response?.status === 429) {
        throw new functions.https.HttpsError('resource-exhausted', 'Translation quota exceeded.');
      }

      throw new functions.https.HttpsError('internal', 'Translation failed. Please try again.');
    }
  });


// ===== HTTP FUNCTION (alternative REST endpoint) =====
/**
 * Alternative HTTP endpoint for use with Retrofit directly.
 *
 * POST /translateHttp
 * Body: { q, source, target }
 * Returns: { translatedText }
 */
exports.translateHttp = functions
  .region('us-central1')
  .https.onRequest(async (req, res) => {

    // CORS headers (restrict to your app's domain in production)
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Access-Control-Allow-Methods', 'POST');
    res.set('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.status(204).send('');
      return;
    }

    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Method not allowed' });
      return;
    }

    const ip = req.ip || 'unknown';
    if (!checkRateLimit(ip)) {
      res.status(429).json({ error: 'Rate limit exceeded' });
      return;
    }

    const { q, source, target } = req.body;

    if (!q || !source || !target) {
      res.status(400).json({ error: 'Missing required fields: q, source, target' });
      return;
    }

    const apiKey = functions.config().rapidapi?.key;
    if (!apiKey) {
      res.status(500).json({ error: 'Server configuration error' });
      return;
    }

    try {
      const response = await axios.post(
        'https://deep-translate1.p.rapidapi.com/language/translate/v2',
        { q, source, target },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-rapidapi-host': 'deep-translate1.p.rapidapi.com',
            'x-rapidapi-key': apiKey,
          },
          timeout: 10000,
        }
      );

      const translatedText = response.data?.data?.translations?.translatedText;
      res.json({ translatedText });

    } catch (error) {
      functions.logger.error('HTTP translate failed:', error.message);
      res.status(500).json({ error: 'Translation failed' });
    }
  });
