# ===== AI Smart Translator ProGuard Rules =====

# Keep data models (needed for Gson serialization/deserialization)
-keep class com.aismartranslator.data.models.** { *; }

# Keep Retrofit interfaces
-keep interface com.aismartranslator.data.api.** { *; }
-dontwarn retrofit2.**
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes Exceptions

# Keep OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Firebase
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.firebase.**

# Gson
-keep class com.google.gson.** { *; }
-keepattributes *Annotation*

# AdMob
-keep class com.google.android.gms.ads.** { *; }

# Keep ViewBinding
-keep class com.aismartranslator.databinding.** { *; }

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-dontwarn kotlinx.coroutines.**
