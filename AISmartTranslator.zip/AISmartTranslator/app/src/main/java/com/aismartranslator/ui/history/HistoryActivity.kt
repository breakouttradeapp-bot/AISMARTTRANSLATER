package com.aismartranslator.ui.history

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.aismartranslator.databinding.ActivityHistoryBinding
import com.aismartranslator.utils.PreferencesManager
import com.aismartranslator.viewmodel.TranslationViewModel

/**
 * HistoryActivity — shows the user's past translations from Firestore.
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private val viewModel: TranslationViewModel by viewModels()
    private lateinit var prefs: PreferencesManager
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PreferencesManager(this)

        supportActionBar?.apply {
            title = "Translation History"
            setDisplayHomeAsUpEnabled(true)
        }

        setupRecyclerView()
        loadHistory()
    }

    private fun setupRecyclerView() {
        adapter = HistoryAdapter { item ->
            // Delete on long press
            viewModel.deleteHistoryItem(prefs.userId, item.id)
        }

        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = adapter

        viewModel.historyItems.observe(this) { items ->
            if (items.isEmpty()) {
                binding.tvEmptyState.visibility = View.VISIBLE
                binding.rvHistory.visibility = View.GONE
            } else {
                binding.tvEmptyState.visibility = View.GONE
                binding.rvHistory.visibility = View.VISIBLE
                adapter.submitList(items)
            }
        }
    }

    private fun loadHistory() {
        viewModel.loadHistory(prefs.userId)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
