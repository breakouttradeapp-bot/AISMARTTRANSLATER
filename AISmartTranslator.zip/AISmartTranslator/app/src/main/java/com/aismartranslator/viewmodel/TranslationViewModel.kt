package com.aismartranslator.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aismartranslator.data.models.HistoryItem
import com.aismartranslator.data.models.Language
import com.aismartranslator.data.models.TranslationState
import com.aismartranslator.data.repository.TranslationRepository
import kotlinx.coroutines.launch

/**
 * ViewModel for MainAcivity.
 * Holds UI state and coordinates with the repository.
 * Survives configuration changes (screen rotation, etc.)
 */
class TranslationViewModel : ViewModel() {

    private val repository = TranslationRepository()

    // ===== TRANSLATION STATE =====
    private val _translationState = MutableLiveData<TranslationState>(TranslationState.Idle)
    val translationState: LiveData<TranslationState> = _translationState

    // ===== HISTORY =====
    private val _historyItems = MutableLiveData<List<HistoryItem>>(emptyList())
    val historyItems: LiveData<List<HistoryItem>> = _historyItems

    // ===== TRANSLATION COUNTER (for interstitial ad logic) =====
    private var translationCount = 0
    private val _showInterstitialAd = MutableLiveData<Boolean>(false)
    val showInterstitialAd: LiveData<Boolean> = _showInterstitialAd

    // ===== SUPPORTED LANGUAGES =====
    val supportedLanguages = listOf(
        Language("English", "en"),
        Language("Hindi", "hi"),
        Language("Marathi", "mr"),
        Language("Spanish", "es"),
        Language("French", "fr"),
        Language("German", "de")
    )

    // Currently selected language indices (for spinner restoration)
    var selectedSourceIndex = 0
    var selectedTargetIndex = 4 // Spanish by default

    /**
     * Main translate function. Calls repository and updates LiveData.
     * @param text - input text to translate
     * @param sourceCode - BCP-47 language code (e.g. "en")
     * @param targetCode - BCP-47 language code (e.g. "es")
     * @param userId - used to save history in Firestore
     */
    fun translate(text: String, sourceCode: String, targetCode: String, userId: String) {
        if (text.isBlank()) {
            _translationState.value = TranslationState.Error("Please enter text to translate.")
            return
        }

        _translationState.value = TranslationState.Loading

        viewModelScope.launch {
            // Use Firebase Callable Function for maximum security
            val result = repository.translateViaFirebaseFunction(text, sourceCode, targetCode)
            _translationState.postValue(result)

            if (result is TranslationState.Success) {
                // Save to history
                repository.saveToHistory(userId, text, result.translatedText, sourceCode, targetCode)

                // Interstitial ad logic: show after every 3 translations
                translationCount++
                if (translationCount % 3 == 0) {
                    _showInterstitialAd.postValue(true)
                }
            }
        }
    }

    /**
     * Load user's translation history from Firestore.
     */
    fun loadHistory(userId: String) {
        viewModelScope.launch {
            val items = repository.getHistory(userId)
            _historyItems.postValue(items)
        }
    }

    /**
     * Delete a history entry.
     */
    fun deleteHistoryItem(userId: String, itemId: String) {
        viewModelScope.launch {
            repository.deleteHistoryItem(userId, itemId)
            loadHistory(userId) // refresh list
        }
    }

    /**
     * Reset the interstitial ad trigger after it has been shown.
     */
    fun onInterstitialAdShown() {
        _showInterstitialAd.value = false
    }

    /**
     * Reset to idle state (e.g., when user clears input).
     */
    fun resetState() {
        _translationState.value = TranslationState.Idle
    }

    /**
     * Convenience: get Language object by spinner index.
     */
    fun getLanguageAt(index: Int): Language = supportedLanguages[index]
}
