package com.aismartranslator.data.models

import com.google.gson.annotations.SerializedName

// ===== REQUEST MODELS =====

/**
 * Request body sent to our Firebase Cloud Function
 * The function will then call RapidAPI (API key never leaves backend)
 */
data class TranslationRequest(
    @SerializedName("q") val text: String,
    @SerializedName("source") val sourceLanguage: String,
    @SerializedName("target") val targetLanguage: String
)

// ===== RESPONSE MODELS =====

/**
 * Top-level response from the translation API
 */
data class TranslationResponse(
    @SerializedName("data") val data: TranslationData?
)

data class TranslationData(
    @SerializedName("translations") val translations: TranslationResult?
)

data class TranslationResult(
    @SerializedName("translatedText") val translatedText: String?
)

// ===== DOMAIN MODELS =====

/**
 * Sealed class representing translation result states
 */
sealed class TranslationState {
    object Idle : TranslationState()
    object Loading : TranslationState()
    data class Success(val translatedText: String) : TranslationState()
    data class Error(val message: String) : TranslationState()
}

/**
 * Language model for spinner dropdown
 */
data class Language(
    val name: String,
    val code: String
) {
    override fun toString(): String = name
}

/**
 * Translation history item stored in Firestore
 */
data class HistoryItem(
    val id: String = "",
    val originalText: String = "",
    val translatedText: String = "",
    val sourceLanguage: String = "",
    val targetLanguage: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    // No-arg constructor required by Firestore
    constructor() : this("", "", "", "", "", 0L)
}

/**
 * Firebase Function response wrapper
 */
data class FunctionResponse(
    @SerializedName("translatedText") val translatedText: String?,
    @SerializedName("error") val error: String?
)
