package com.aismartranslator.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import com.aismartranslator.R

/**
 * Extension functions used throughout the app.
 */

/** Show a short toast. */
fun Context.showToast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

/** Copy text to system clipboard. */
fun Context.copyToClipboard(text: String, label: String = "Translated Text") {
    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    showToast("Copied to clipboard!")
}

/** Apply a bounce animation to a view. */
fun View.bounceAnimation(context: Context) {
    startAnimation(AnimationUtils.loadAnimation(context, R.anim.bounce))
}

/** Show view with fade-in. */
fun View.fadeIn() {
    visibility = View.VISIBLE
    alpha = 0f
    animate().alpha(1f).setDuration(300).start()
}

/** Hide view with fade-out. */
fun View.fadeOut(gone: Boolean = true) {
    animate().alpha(0f).setDuration(300).withEndAction {
        visibility = if (gone) View.GONE else View.INVISIBLE
    }.start()
}
