package com.aismartranslator.utils

import android.app.Activity
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Manages AdMob banner and interstitial ads.
 *
 * TEST AD UNIT IDs are used here — replace with production IDs before release.
 * Test IDs: https://developers.google.com/admob/android/test-ads
 *
 * IMPORTANT: Never show ads to premium users.
 */
class AdManager(private val activity: Activity) {

    private var interstitialAd: InterstitialAd? = null
    private val TAG = "AdManager"

    companion object {
        // Test Ad Unit IDs — REPLACE with real ones from AdMob console
        const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"       // Test banner
        const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712" // Test interstitial
    }

    /**
     * Initialize the AdMob SDK. Call once in Application or first Activity.
     */
    fun initialize(onComplete: () -> Unit = {}) {
        MobileAds.initialize(activity) {
            Log.d(TAG, "AdMob initialized")
            onComplete()
        }
    }

    /**
     * Load the banner ad into the provided AdView.
     * Attach the AdView in your layout with the BANNER_AD_UNIT_ID.
     */
    fun loadBannerAd(adView: AdView) {
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() {
                Log.d(TAG, "Banner ad loaded")
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                Log.e(TAG, "Banner failed to load: ${error.message}")
            }
        }
        adView.loadAd(AdRequest.Builder().build())
    }

    /**
     * Pre-load interstitial ad so it's ready when needed.
     * Call this after a successful translation.
     */
    fun loadInterstitialAd() {
        InterstitialAd.load(
            activity,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Interstitial loaded")
                    interstitialAd = ad
                    setupInterstitialCallbacks()
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "Interstitial failed: ${error.message}")
                    interstitialAd = null
                }
            }
        )
    }

    /**
     * Show the interstitial ad if loaded, then reload for next use.
     * @param onDismissed - callback after ad is dismissed (e.g. to reset counter)
     */
    fun showInterstitialAd(onDismissed: () -> Unit) {
        if (interstitialAd != null) {
            interstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitialAd() // Preload next
                    onDismissed()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    onDismissed()
                }
            }
            interstitialAd!!.show(activity)
        } else {
            // Ad not ready yet; just proceed
            loadInterstitialAd()
            onDismissed()
        }
    }

    private fun setupInterstitialCallbacks() {
        interstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "Interstitial shown")
            }
        }
    }

    /** Call in Activity.onPause() */
    fun pauseBannerAd(adView: AdView) = adView.pause()

    /** Call in Activity.onResume() */
    fun resumeBannerAd(adView: AdView) = adView.resume()

    /** Call in Activity.onDestroy() */
    fun destroyBannerAd(adView: AdView) = adView.destroy()
}
