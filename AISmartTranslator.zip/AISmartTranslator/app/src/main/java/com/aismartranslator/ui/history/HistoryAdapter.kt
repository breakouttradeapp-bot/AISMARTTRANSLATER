package com.aismartranslator.ui.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aismartranslator.data.models.HistoryItem
import com.aismartranslator.databinding.ItemHistoryBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RecyclerView Adapter for the translation history list.
 * Uses ListAdapter with DiffUtil for efficient updates.
 */
class HistoryAdapter(
    private val onDelete: (HistoryItem) -> Unit
) : ListAdapter<HistoryItem, HistoryAdapter.ViewHolder>(DiffCallback) {

    private val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())

    inner class ViewHolder(private val binding: ItemHistoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: HistoryItem) {
            binding.tvOriginalText.text = item.originalText
            binding.tvTranslatedText.text = item.translatedText
            binding.tvLanguagePair.text =
                "${item.sourceLanguage.uppercase()} → ${item.targetLanguage.uppercase()}"
            binding.tvTimestamp.text = dateFormat.format(Date(item.timestamp))

            binding.btnDelete.setOnClickListener {
                onDelete(item)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object DiffCallback : DiffUtil.ItemCallback<HistoryItem>() {
        override fun areItemsTheSame(old: HistoryItem, new: HistoryItem) = old.id == new.id
        override fun areContentsTheSame(old: HistoryItem, new: HistoryItem) = old == new
    }
}
