package com.aismartranslator.ui.main

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.aismartranslator.R
import com.aismartranslator.data.models.TranslationState
import com.aismartranslator.databinding.ActivityMainBinding
import com.aismartranslator.ui.history.HistoryActivity
import com.aismartranslator.utils.AdManager
import com.aismartranslator.utils.NetworkUtils
import com.aismartranslator.utils.PreferencesManager
import com.aismartranslator.utils.bounceAnimation
import com.aismartranslator.utils.copyToClipboard
import com.aismartranslator.utils.fadeIn
import com.aismartranslator.utils.fadeOut
import com.aismartranslator.utils.showToast
import com.aismartranslator.viewmodel.TranslationViewModel
import java.util.Locale
import java.util.UUID

/**
 * MainActivity — The main translation screen.
 *
 * Features:
 * - Language spinners with swap functionality
 * - Translation via Firebase Cloud Function (secure)
 * - Text-to-Speech for results
 * - Voice input via SpeechRecognizer
 * - Translation history
 * - AdMob banner + interstitial
 * - Dark mode toggle
 * - Premium (ad-free) mode
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: TranslationViewModel by viewModels()
    private lateinit var prefs: PreferencesManager
    private lateinit var adManager: AdManager
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    // Speech recognizer result launcher
    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            spokenText?.let { binding.etInputText.setText(it) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PreferencesManager(this)
        ensureUserId()
        applyDarkMode()
        setupToolbar()
        setupLanguageSpinners()
        setupClickListeners()
        setupObservers()
        setupAds()
        initTts()
    }

    // ===== SETUP METHODS =====

    private fun ensureUserId() {
        if (prefs.userId.isEmpty()) {
            prefs.userId = UUID.randomUUID().toString()
        }
    }

    private fun applyDarkMode() {
        AppCompatDelegate.setDefaultNightMode(
            if (prefs.isDarkMode) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)
    }

    private fun setupLanguageSpinners() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            viewModel.supportedLanguages
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        binding.spinnerSource.adapter = adapter
        binding.spinnerTarget.adapter = adapter

        // Restore saved selections
        binding.spinnerSource.setSelection(prefs.sourceLangIndex)
        binding.spinnerTarget.setSelection(prefs.targetLangIndex)
    }

    private fun setupClickListeners() {
        // Translate button
        binding.btnTranslate.setOnClickListener {
            it.bounceAnimation(this)
            performTranslation()
        }

        // Swap languages button
        binding.btnSwap.setOnClickListener {
            it.bounceAnimation(this)
            swapLanguages()
        }

        // Copy result button
        binding.btnCopy.setOnClickListener {
            val text = binding.tvResult.text.toString()
            if (text.isNotBlank() && text != getString(R.string.translation_placeholder)) {
                copyToClipboard(text)
            } else {
                showToast("Nothing to copy yet!")
            }
        }

        // Text-to-Speech button
        binding.btnTts.setOnClickListener {
            speakResult()
        }

        // Voice input (mic) button
        binding.btnMic.setOnClickListener {
            startVoiceInput()
        }

        // Clear input
        binding.btnClearInput.setOnClickListener {
            binding.etInputText.text?.clear()
            binding.tvResult.text = getString(R.string.translation_placeholder)
            binding.cardResult.visibility = View.INVISIBLE
            viewModel.resetState()
        }
    }

    private fun setupObservers() {
        // Translation state
        viewModel.translationState.observe(this) { state ->
            when (state) {
                is TranslationState.Idle -> {
                    binding.progressBar.visibility = View.GONE
                }
                is TranslationState.Loading -> {
                    binding.progressBar.fadeIn()
                    binding.btnTranslate.isEnabled = false
                    binding.tvError.visibility = View.GONE
                }
                is TranslationState.Success -> {
                    binding.progressBar.fadeOut()
                    binding.btnTranslate.isEnabled = true
                    binding.tvResult.text = state.translatedText
                    binding.cardResult.fadeIn()
                    binding.tvError.visibility = View.GONE
                    // Preload next interstitial
                    if (!prefs.isPremium) adManager.loadInterstitialAd()
                }
                is TranslationState.Error -> {
                    binding.progressBar.fadeOut()
                    binding.btnTranslate.isEnabled = true
                    binding.tvError.text = state.message
                    binding.tvError.fadeIn()
                }
            }
        }

        // Interstitial ad trigger (every 3 translations)
        viewModel.showInterstitialAd.observe(this) { shouldShow ->
            if (shouldShow && !prefs.isPremium) {
                adManager.showInterstitialAd {
                    viewModel.onInterstitialAdShown()
                }
            }
        }
    }

    private fun setupAds() {
        adManager = AdManager(this)
        adManager.initialize()

        if (prefs.isPremium) {
            // Hide banner for premium users
            binding.adView.visibility = View.GONE
            binding.adBannerContainer.visibility = View.GONE
        } else {
            adManager.loadBannerAd(binding.adView)
        }
    }

    private fun initTts() {
        tts = TextToSpeech(this, this)
    }

    // ===== CORE ACTIONS =====

    private fun performTranslation() {
        if (!NetworkUtils.isNetworkAvailable(this)) {
            showToast(getString(R.string.no_internet))
            return
        }

        val inputText = binding.etInputText.text.toString().trim()
        if (inputText.isEmpty()) {
            showToast(getString(R.string.enter_text_prompt))
            return
        }

        val sourceLang = viewModel.getLanguageAt(binding.spinnerSource.selectedItemPosition)
        val targetLang = viewModel.getLanguageAt(binding.spinnerTarget.selectedItemPosition)

        if (sourceLang.code == targetLang.code) {
            showToast("Source and target language must be different!")
            return
        }

        // Save preferences
        prefs.sourceLangIndex = binding.spinnerSource.selectedItemPosition
        prefs.targetLangIndex = binding.spinnerTarget.selectedItemPosition

        viewModel.translate(inputText, sourceLang.code, targetLang.code, prefs.userId)
    }

    private fun swapLanguages() {
        val sourcePos = binding.spinnerSource.selectedItemPosition
        val targetPos = binding.spinnerTarget.selectedItemPosition

        binding.spinnerSource.setSelection(targetPos)
        binding.spinnerTarget.setSelection(sourcePos)

        // Also swap text if there's a result
        val currentInput = binding.etInputText.text.toString()
        val currentResult = binding.tvResult.text.toString()
        if (currentResult.isNotBlank() && currentResult != getString(R.string.translation_placeholder)) {
            binding.etInputText.setText(currentResult)
            binding.tvResult.text = currentInput
        }
    }

    private fun speakResult() {
        val text = binding.tvResult.text.toString()
        if (text.isBlank() || text == getString(R.string.translation_placeholder)) {
            showToast("No translation to speak yet!")
            return
        }
        if (!isTtsReady) {
            showToast("Text-to-Speech not ready yet.")
            return
        }

        val targetLang = viewModel.getLanguageAt(binding.spinnerTarget.selectedItemPosition)
        val locale = Locale(targetLang.code)
        val result = tts?.setLanguage(locale)

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fall back to English
            tts?.language = Locale.ENGLISH
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tts_utterance")
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)

            // Set recognition language to source language
            val sourceLang = viewModel.getLanguageAt(binding.spinnerSource.selectedItemPosition)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, sourceLang.code)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...")
        }

        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            showToast("Voice input not available on this device.")
        }
    }

    // ===== MENU =====

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        // Show/hide dark mode icon based on current setting
        menu.findItem(R.id.action_dark_mode)?.setIcon(
            if (prefs.isDarkMode) R.drawable.ic_light_mode else R.drawable.ic_dark_mode
        )
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
                true
            }
            R.id.action_dark_mode -> {
                prefs.isDarkMode = !prefs.isDarkMode
                applyDarkMode()
                recreate()
                true
            }
            R.id.action_premium -> {
                startActivity(Intent(this, PremiumActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // ===== LIFECYCLE =====

    override fun onInit(status: Int) {
        isTtsReady = status == TextToSpeech.SUCCESS
    }

    override fun onPause() {
        adManager.pauseBannerAd(binding.adView)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        adManager.resumeBannerAd(binding.adView)

        // Re-check premium status (user may have just purchased)
        if (prefs.isPremium) {
            binding.adView.visibility = View.GONE
            binding.adBannerContainer.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        tts?.apply {
            stop()
            shutdown()
        }
        adManager.destroyBannerAd(binding.adView)
        super.onDestroy()
    }
}
