package com.aismartranslator.data.api

import com.aismartranslator.data.models.FunctionResponse
import com.aismartranslator.data.models.TranslationRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Retrofit interface for calling our Firebase Cloud Function.
 *
 * SECURITY NOTE:
 * We call our own Firebase Function endpoint, NOT RapidAPI directly.
 * The API key is stored securely in Firebase environment config and
 * never shipped inside the APK.
 */
interface TranslationApiService {

    @POST("translate")
    suspend fun translate(
        @Body request: TranslationRequest
    ): Response<FunctionResponse>
}
