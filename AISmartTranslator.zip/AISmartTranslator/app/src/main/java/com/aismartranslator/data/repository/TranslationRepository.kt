package com.aismartranslator.data.repository

import com.aismartranslator.data.api.NetworkClient
import com.aismartranslator.data.models.FunctionResponse
import com.aismartranslator.data.models.HistoryItem
import com.aismartranslator.data.models.TranslationRequest
import com.aismartranslator.data.models.TranslationState
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Repository that handles all translation operations.
 *
 * Two translation strategies:
 * 1. [translateViaFirebaseFunction] — calls Firebase Callable Function (recommended, most secure)
 * 2. [translateViaRetrofit] — calls Firebase HTTP Function via Retrofit
 *
 * History is stored in Firestore under "history/{userId}/items"
 */
class TranslationRepository {

    private val firestore = FirebaseFirestore.getInstance()
    private val functions = FirebaseFunctions.getInstance()
    private val apiService = NetworkClient.translationApiService
    private val gson = Gson()

    // Rate limiting: max 30 translations per minute
    private var requestCount = 0
    private var windowStart = System.currentTimeMillis()
    private val RATE_LIMIT = 30
    private val WINDOW_MS = 60_000L

    /**
     * Translate text using Firebase Callable Cloud Function.
     * This is the most secure approach — the API key is NEVER in the APK.
     */
    suspend fun translateViaFirebaseFunction(
        text: String,
        source: String,
        target: String
    ): TranslationState = withContext(Dispatchers.IO) {
        try {
            // Rate limit check
            if (!checkRateLimit()) {
                return@withContext TranslationState.Error(
                    "Rate limit reached. Please wait before translating again."
                )
            }

            val data = hashMapOf(
                "q" to text,
                "source" to source,
                "target" to target
            )

            // Call the Firebase Callable Function named "translate"
            val result = functions
                .getHttpsCallable("translate")
                .call(data)
                .await()

            @Suppress("UNCHECKED_CAST")
            val resultData = result.data as? Map<String, Any>
            val translatedText = resultData?.get("translatedText") as? String

            if (translatedText != null) {
                TranslationState.Success(translatedText)
            } else {
                TranslationState.Error("Translation failed. Empty response.")
            }

        } catch (e: Exception) {
            TranslationState.Error(e.localizedMessage ?: "Unknown error occurred")
        }
    }

    /**
     * Alternative: Translate via Retrofit HTTP call to Firebase HTTP Function.
     * Use this if you prefer REST over callable functions.
     */
    suspend fun translateViaRetrofit(
        text: String,
        source: String,
        target: String
    ): TranslationState = withContext(Dispatchers.IO) {
        try {
            if (!checkRateLimit()) {
                return@withContext TranslationState.Error("Rate limit reached. Please wait.")
            }

            val request = TranslationRequest(text, source, target)
            val response = apiService.translate(request)

            if (response.isSuccessful) {
                val body = response.body()
                val translatedText = body?.translatedText
                if (translatedText != null) {
                    TranslationState.Success(translatedText)
                } else {
                    TranslationState.Error("No translation returned.")
                }
            } else {
                TranslationState.Error("Error ${response.code()}: ${response.message()}")
            }

        } catch (e: Exception) {
            TranslationState.Error(e.localizedMessage ?: "Network error")
        }
    }

    /**
     * Save a translation to Firestore history.
     * userId can be "anonymous" for unauthenticated users.
     */
    suspend fun saveToHistory(
        userId: String,
        originalText: String,
        translatedText: String,
        sourceLang: String,
        targetLang: String
    ) = withContext(Dispatchers.IO) {
        try {
            val item = HistoryItem(
                id = UUID.randomUUID().toString(),
                originalText = originalText,
                translatedText = translatedText,
                sourceLanguage = sourceLang,
                targetLanguage = targetLang,
                timestamp = System.currentTimeMillis()
            )

            firestore.collection("history")
                .document(userId)
                .collection("items")
                .document(item.id)
                .set(item)
                .await()
        } catch (e: Exception) {
            // History save failure is non-critical; log silently
            e.printStackTrace()
        }
    }

    /**
     * Fetch recent translation history for the user (last 50 items).
     */
    suspend fun getHistory(userId: String): List<HistoryItem> =
        withContext(Dispatchers.IO) {
            return@withContext try {
                val snapshot = firestore.collection("history")
                    .document(userId)
                    .collection("items")
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .limit(50)
                    .get()
                    .await()

                snapshot.toObjects(HistoryItem::class.java)
            } catch (e: Exception) {
                emptyList()
            }
        }

    /**
     * Delete a history item.
     */
    suspend fun deleteHistoryItem(userId: String, itemId: String) =
        withContext(Dispatchers.IO) {
            try {
                firestore.collection("history")
                    .document(userId)
                    .collection("items")
                    .document(itemId)
                    .delete()
                    .await()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    /**
     * Simple in-memory rate limiter.
     * Resets every 60 seconds, max 30 calls per window.
     */
    private fun checkRateLimit(): Boolean {
        val now = System.currentTimeMillis()
        if (now - windowStart > WINDOW_MS) {
            requestCount = 0
            windowStart = now
        }
        return if (requestCount < RATE_LIMIT) {
            requestCount++
            true
        } else {
            false
        }
    }
}
