package com.aismartranslator.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * SharedPreferences manager for user settings and premium status.
 */
class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "translator_prefs"
        private const val KEY_IS_PREMIUM = "is_premium"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_TTS_ENABLED = "tts_enabled"
        private const val KEY_SOURCE_LANG_INDEX = "source_lang_index"
        private const val KEY_TARGET_LANG_INDEX = "target_lang_index"
    }

    // ===== PREMIUM STATUS =====

    var isPremium: Boolean
        get() = prefs.getBoolean(KEY_IS_PREMIUM, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_PREMIUM, value).apply()

    // ===== DARK MODE =====

    var isDarkMode: Boolean
        get() = prefs.getBoolean(KEY_DARK_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_DARK_MODE, value).apply()

    // ===== USER ID (anonymous persistent ID) =====

    var userId: String
        get() = prefs.getString(KEY_USER_ID, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_ID, value).apply()

    // ===== TEXT-TO-SPEECH =====

    var ttsEnabled: Boolean
        get() = prefs.getBoolean(KEY_TTS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_TTS_ENABLED, value).apply()

    // ===== LANGUAGE PREFERENCES =====

    var sourceLangIndex: Int
        get() = prefs.getInt(KEY_SOURCE_LANG_INDEX, 0)
        set(value) = prefs.edit().putInt(KEY_SOURCE_LANG_INDEX, value).apply()

    var targetLangIndex: Int
        get() = prefs.getInt(KEY_TARGET_LANG_INDEX, 4) // Default: Spanish
        set(value) = prefs.edit().putInt(KEY_TARGET_LANG_INDEX, value).apply()
}
