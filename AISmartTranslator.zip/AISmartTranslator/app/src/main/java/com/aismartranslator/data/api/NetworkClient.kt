package com.aismartranslator.data.api

import com.aismartranslator.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Singleton Retrofit client.
 * Base URL points to our Firebase Cloud Function — NOT RapidAPI.
 * API key never lives in this app.
 */
object NetworkClient {

    // Firebase Cloud Function base URL (set in build.gradle per flavor)
    private val BASE_URL = BuildConfig.FIREBASE_FUNCTION_URL
        .removeSuffix("translate") // keep base path only

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        // Only log in debug builds
        level = if (BuildConfig.DEBUG)
            HttpLoggingInterceptor.Level.BODY
        else
            HttpLoggingInterceptor.Level.NONE
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val translationApiService: TranslationApiService =
        retrofit.create(TranslationApiService::class.java)
}
