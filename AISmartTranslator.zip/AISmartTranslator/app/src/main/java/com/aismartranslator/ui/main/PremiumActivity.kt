package com.aismartranslator.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.aismartranslator.databinding.ActivityPremiumBinding
import com.aismartranslator.utils.PreferencesManager
import com.aismartranslator.utils.showToast

/**
 * PremiumActivity — "Remove Ads" upgrade screen.
 *
 * In a real app, integrate Google Play Billing here.
 * For now we simulate with a toggle (for testing).
 *
 * Production flow:
 *  1. User taps "Upgrade"
 *  2. Launch Google Play Billing flow
 *  3. On purchase confirmed → set prefs.isPremium = true
 *  4. Optionally verify receipt server-side via Firebase Function
 */
class PremiumActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPremiumBinding
    private lateinit var prefs: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPremiumBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PreferencesManager(this)

        supportActionBar?.apply {
            title = "Go Premium"
            setDisplayHomeAsUpEnabled(true)
        }

        updatePremiumStatus()

        binding.btnUpgrade.setOnClickListener {
            // TODO: Integrate Google Play Billing here
            // Simulating purchase for demo:
            prefs.isPremium = true
            updatePremiumStatus()
            showToast("Welcome to Premium! Ads removed.")
        }

        binding.btnRestorePurchase.setOnClickListener {
            // TODO: Query existing purchases from Play Billing
            showToast("Checking existing purchases...")
        }
    }

    private fun updatePremiumStatus() {
        if (prefs.isPremium) {
            binding.tvPremiumStatus.text = "✓ You are a Premium member!"
            binding.btnUpgrade.isEnabled = false
            binding.btnUpgrade.text = "Already Premium"
        } else {
            binding.tvPremiumStatus.text = "Upgrade to remove all ads"
            binding.btnUpgrade.isEnabled = true
            binding.btnUpgrade.text = "Upgrade — ₹99 / $1.99"
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
